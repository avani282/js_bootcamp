import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>HTML - CSS </h1>
      <p>Basic of Html and css.</p>
    </div>
  );
}
export default Info;
